using UnityEngine;
using Zenject;

namespace ModestTree
{
    public class BarMono1 : MonoBehaviour, IInitializable
    {
        public void Initialize()
        {
        }
    }
}
