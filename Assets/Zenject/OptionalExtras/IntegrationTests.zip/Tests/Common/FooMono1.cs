﻿using UnityEngine;
using Zenject;

namespace ModestTree
{
    public class FooMono1 : MonoBehaviour, IInitializable
    {
        public void Initialize()
        {
        }
    }
}
